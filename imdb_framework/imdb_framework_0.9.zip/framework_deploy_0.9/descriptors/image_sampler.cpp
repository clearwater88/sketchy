/*
Copyright (C) 2012 Mathias Eitz and Ronald Richter.
All rights reserved.

This file is part of the imdb library and is made available under
the terms of the BSD license (see the LICENSE file).
*/

#include "image_sampler.hpp"

#include <ctime>
#include <algorithm>

#include <boost/random.hpp>

namespace imdb {


shared_ptr<ImageSampler> makeSampler(const string& name, ptree& params)
{

    if (name == "grid")
    {
        //cv::Rect rect(0, 0, image.size().width, image.size().height);
        uint numSamples = parse<uint>(params, "num_samples", 625);
        return make_shared<grid_sampler>(numSamples);
    }
    else if (name == "random_area")
    {
        //std::cout << image.size().width << ", " << image.size().height << std::endl;
        //cv::Rect rect(0, 0, image.size().width, image.size().height);
        uint numSamples = parse<uint>(params, "num_samples", 500);
        return make_shared<random_area_sampler>(numSamples);
    }
    else throw std::runtime_error("unavailable sampler " + name);
}



grid_sampler::grid_sampler(uint numSamples) :
    _numSamples(numSamples)
{}

// the resulting samples contain (x,y) coordinates within the sampling area
void grid_sampler::sample(vector<cv::Point2f>& samples, const cv::Mat& image) const
{
    cv::Rect samplingArea(0, 0, image.size().width, image.size().height);


    uint numSamples1D = std::ceil(std::sqrt(static_cast<float>(_numSamples)));
    float stepX = samplingArea.width / static_cast<float>(numSamples1D+1);
    float stepY = samplingArea.height / static_cast<float>(numSamples1D+1);

    for (uint x = 1; x <= numSamples1D; x++) {
        uint posX = x*stepX;
        for (uint y = 1; y <= numSamples1D; y++) {
            uint posY = y*stepY;
            samples.push_back(cv::Point2f(posX,posY));
        }
    }
}

// -----------------------------------------------------------------------------------------------------------------------

random_area_sampler::random_area_sampler(unsigned int numSamples) :
    _numSamples(numSamples)
{}

void random_area_sampler::sample(vector<cv::Point2f>& samples, const cv::Mat& image) const
{
    // prevent logical error
    assert(samples.size() == 0);

    cv::Rect samplingArea(0, 0, image.size().width, image.size().height);

    int w = samplingArea.width;
    int h = samplingArea.height;

    // TODO: move rng and seed to constructor???
    boost::mt19937 rng;
    rng.seed(static_cast<unsigned int>(std::time(0)));


    boost::variate_generator<boost::mt19937&, boost::uniform_int<> > x_generator(rng, boost::uniform_int<>(0,w-1));
    boost::variate_generator<boost::mt19937&, boost::uniform_int<> > y_generator(rng, boost::uniform_int<>(0,h-1));

    for (uint i = 0; i < _numSamples; i++)
    {
        int x = x_generator();
        int y = y_generator();
        samples.push_back(cv::Point2f(x,y));
    }
}

} // end namespace
