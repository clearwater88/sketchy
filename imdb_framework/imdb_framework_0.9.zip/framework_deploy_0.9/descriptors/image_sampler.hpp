/*
Copyright (C) 2012 Mathias Eitz and Ronald Richter.
All rights reserved.

This file is part of the imdb library and is made available under
the terms of the BSD license (see the LICENSE file).
*/

#ifndef IMAGE_SAMPLER_H
#define IMAGE_SAMPLER_H

#include <vector>
#include <opencv2/imgproc/imgproc.hpp>
#include "../util/types.hpp"

namespace imdb {


class ImageSampler {
public:
    virtual ~ImageSampler() {}
    virtual void sample(vector<cv::Point2f>& samples, const cv::Mat& image) const=0;
};


// ---------------------------------------------------------------------------
// simple factory method that creates a sampler from a name and an appropriate
// property tree containing the sampler's parameters. If some parameters are
// not specified in the property tree, the samplers default parameters are
// used and also inserted into the property tree (that's why it's not const!)
shared_ptr<ImageSampler> makeSampler(const string& name, ptree& params);
// ---------------------------------------------------------------------------

class grid_sampler : public ImageSampler
{
public:

    grid_sampler(uint numSamples);
    virtual ~grid_sampler() {}
    void sample(vector<cv::Point2f>& samples, const cv::Mat &image) const;

private:

    //const cv::Rect _samplingArea;
    uint _numSamples;
};


class random_area_sampler : public ImageSampler
{
public:

    random_area_sampler(unsigned int numSamples);
    virtual ~random_area_sampler() {}
    void sample(vector<cv::Point2f>& samples, const cv::Mat &image) const;

private:

    const cv::Rect _samplingArea;
    unsigned int _numSamples;
};


} // end namespace

#endif // IMAGE_SAMPLER_H
