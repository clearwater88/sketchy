/*
Copyright (C) 2012 Mathias Eitz and Ronald Richter.
All rights reserved.

This file is part of the imdb library and is made available under
the terms of the BSD license (see the LICENSE file).
*/

#include "bof_3d_search_manager.hpp"

#include <io/property_reader.hpp>
#include <search/map_views.hpp>

namespace imdb {

Bof3DSearchManager::Bof3DSearchManager(const ptree& parameters) : _bofSearchManager(parameters)
{
    string mapping_file = parameters.get<string>("mapping_file");

    try {
        read_property(_mapping, mapping_file);
    } catch(std::exception& e) {
        std::cerr << "Bof3DSearchManager: exception occured when trying to load mapping file: " + mapping_file << ": " << std::endl;
        std::cerr << e.what() << std::endl;
    }
}

void Bof3DSearchManager::query(const vec_f32_t& histvw, vector<dist_idx_t>& result_views, vector<dist_idx_t>& views_mapped, vector<dist_idx_t>& models_mapped)
{

    // Perform a bof search search over *all* the views, each model
    // is typically represented by many views. The result is stored
    // in result_views and contains the distance/id pairs for all views
    // Any content already contained in result_views will be internally cleared!
    _bofSearchManager.query(histvw, _bofSearchManager.index().num_documents(), result_views);

    // compute the best-matching view per model (views_mapped) and the model (models_mapped)
    map_views_to_model(_mapping, result_views, views_mapped, models_mapped);
}

} // end namespace imdb
