/*
Copyright (C) 2012 Mathias Eitz and Ronald Richter.
All rights reserved.

This file is part of the imdb library and is made available under
the terms of the BSD license (see the LICENSE file).
*/

#ifndef BOF_3D_SEARCH_MANAGER_HPP
#define BOF_3D_SEARCH_MANAGER_HPP

#include "bof_search_manager.hpp"

namespace imdb {


/**
 * @ingroup search
 * @brief 3D shape search using a bag-of-features view-based approach.
 *
 * Encapsulates loading of the required datastructures to perform a search using
 * an InvertedIndex. Also encapsulates the mapping back from the retrieved views
 * to the model ids (as we search for 3D shapes, we want indices to those as a
 * results rather than only indices to the underlying views).
 */
class Bof3DSearchManager {

public:

    /**
     * @brief Loads all required datastructures such that a query() can be performed.
     * @param parameters A boost::property_tree holding four key/value pairs:
     * - "mapping_file": path to the mapping file that holds information about which view ids belong to which model, e.g. "tmp/mapping.data"
     * - "index_file": path to the filename of the InvertedIndex to load, e.g. "/tmp/index.data"
     * - "tf": name of the tf_function used to weigh the query histogram, e.g. "video_google", you probably
     * want to use the same function you used when constructing the InvertedIndex
     * - "idf": name of the idf_function used to weigh the query histogram, e.g. "video_google", you probably
     * want to use the same function you used when constructing the InvertedIndex
     */
    Bof3DSearchManager(const ptree& parameters);


    /**
     * @brief Perform a query for the most similar 3D shapes on the InvertedIndex.
     *
     * Note that the results vectors (result_views, views_mapped, models_mapped) are cleared before
     * the new results are added.
     *
     * @param histvw Histogram of visual words encoding a query 'document' (view of a 3D shape)
     * @param num_results Desired number of results
     * @param result_views A vector of dist_idx_t that holds the best matching \b view index/similarity pairs in descending order of
     * similarity (i.e. best matches are first in the vector).
     * @param views_mapped Same as result_views but contains only the best-matching \b view index per model
     * @param models_mapped Same as views_mapped but this time contains the coresponding \b model indices
     */
    void query(const vec_f32_t& histvw, vector<dist_idx_t>& result_views, vector<dist_idx_t>& views_mapped, vector<dist_idx_t>& models_mapped);

private:

    BofSearchManager _bofSearchManager;
    vector<index_t> _mapping;
};

} // end namespace


#endif // BOF_3D_SEARCH_MANAGER_HPP
