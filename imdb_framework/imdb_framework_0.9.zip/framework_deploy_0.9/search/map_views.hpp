/*
Copyright (C) 2012 Mathias Eitz and Ronald Richter.
All rights reserved.

This file is part of the imdb library and is made available under
the terms of the BSD license (see the LICENSE file).
*/

#ifndef MAP_VIEWS_HPP
#define MAP_VIEWS_HPP

#include <set>
#include <util/types.hpp>

namespace imdb {

/**
 * @ingroup search
 * @brief Helper function for 3D shape retrieval mapping view indices to model indices.
 *
 * In Bof3DSearchManager we actually search for best-matching views in a first step.
 * This function filters out views belonging to the same model. It keeps only
 * the best matching view for each model and assigns its distance as the model distance
 * and returns the model indices corresponding to the filtered views.
 *
 * @param mapping vector holding the mapping from view to models, i.e. mapping[i]=k means
 * that view i belongs to model k
 * @param result_views resulting view distances and ids (unmapped)
 * @param views_mapped views_mapped[i]: distance and view_id corresponding to the ith best match
 * @param models_mapped models_mapped[i]: distance and model_id corresponding to the ith best match,
 * i.e. models_mapped[i].second gives the id of the model of the ith best match. Note that
 * views_mapped[i].first = models_mapped[i].second.
 */
template <class mapping_t, class result_t>
void map_views_to_model(const mapping_t& mapping, const result_t& result_views, result_t& views_mapped, result_t&  models_mapped)
{
    using namespace std;

    // clear vectors supposed to hold the results and reserve
    // enough storage to avoid frequent re-allocations
    views_mapped.clear();
    views_mapped.reserve(result_views.size());
    models_mapped.clear();
    models_mapped.reserve(result_views.size());

    typedef typename mapping_t::value_type index_t;
    set<index_t> resultIndices;
    for (size_t i = 0; i < result_views.size(); i++)
    {
        double viewDist = result_views[i].first;
        index_t viewIndex = result_views[i].second;
        index_t modelIndex = mapping[viewIndex];

        if (!resultIndices.count(modelIndex))
        {
            resultIndices.insert(modelIndex);
            models_mapped.push_back(make_pair(viewDist, modelIndex));
            views_mapped.push_back(make_pair(viewDist, viewIndex));
        }
    }
}

} // end namespace imdb

#endif // MAP_VIEWS_HPP
